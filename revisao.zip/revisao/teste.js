nome = "vitor"

lista = []